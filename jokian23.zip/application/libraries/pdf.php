<?php
    class pdf{
        function __construct()
        {
            include APPPATH . 'third_party/fpdf/fpdf.php';
        }

    }
?>